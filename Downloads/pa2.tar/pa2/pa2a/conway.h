#ifndef _CONWAY_H_
#define _CONWAY_H_

extern int update(int **board, int width, int height);

#endif
