package apps;

import java.io.*;
import java.util.*;

import structures.FriendshipGraph;

//Eric Bronner and Shina Kolisetti
/**User-Interface class
 * 
 * @author Eric
 *
 */
public class Friends{
	
	static Scanner entry = new Scanner(System.in);
	
	static char getOption(){
		System.out.println("\tChoose action: ");
		System.out.println("(1)Learn which students go to any school");
		System.out.println("(2)Learn the fastest way for someone to be introduced to someone else");
		System.out.println("(3)Learn the cliques at your school");
		System.out.println("(4)Learn which friends keep friends together");
		System.out.println("(5)quit?");
		System.out.print("\tEnter option:");
		char response = entry.next().toLowerCase().charAt(0);
		while(response != '1' && response != '2' && response != '3' && response != '4' && response != '5'){
			System.out.println("\tYou must select one of the above choices");
			System.out.print("\tEnter option:");
			response = entry.next().toLowerCase().charAt(0);
		}
		return response;
	}
	
	public static void main(String[] args)
	throws IOException{
		System.out.print("Enter graph file name here: ");
		String graphFile = entry.next();
		FriendshipGraph friendship = new FriendshipGraph(new Scanner(new File(graphFile)));
		friendship.build();
		char option;
		while ((option = getOption()) != '5'){
			if(option == '1'){
				System.out.print("\tEnter the name of the school to find all of it's students:");
				String schoolStudents = entry.next();
				schoolStudents = schoolStudents.toLowerCase();
				FriendshipGraph subgraph = friendship.studentsAtASchool(schoolStudents);
				subgraph.print();
			}else if (option == '2'){
				System.out.print("\tEnter the name of the person who would like to get introduced:");
				String wantsIntro = entry.next();
				System.out.print("\tEnter the name of the person who he or she would like to be introduced to:");
				String getsIntrod = entry.next();
				String result = friendship.introChain(wantsIntro,getsIntrod);
				System.out.println(result);
			}else if (option == '3'){
				System.out.print("\tEnter the name of the school to find it's cliques:");
				String schoolCliques = entry.next();
				FriendshipGraph subgraph = friendship.studentsAtASchool(schoolCliques);
				System.out.println(subgraph.cliques());
			}else if (option == '4'){
				friendship.connectors();
			}
		}
	}
}
