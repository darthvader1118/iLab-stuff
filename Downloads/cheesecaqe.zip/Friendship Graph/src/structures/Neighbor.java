package structures;

/**
 * 
 * @author Eric
 *	Edge class
 *fields: name of the person the edge connects (for Sam<->Jon, Jon has edge Sam, Sam has edge Jon), 'next' for linked list
 */
public class Neighbor {

	public String stdName; //name of friend
	public String vertexName; //vertex friend belongs to
	public Neighbor next;
	
	public Neighbor(String vertexName, String stdName){
		this.stdName = stdName;
		this.vertexName = vertexName;
		this.next = null;
	}
	
	public Neighbor(String vertexName, String stdName, Neighbor next){
		this.stdName = stdName;
		this.vertexName = vertexName;
		this.next = next;
	}
	
	public boolean equals(Neighbor cmp){
		if(cmp != null){
			return (vertexName.equals(cmp.vertexName) && stdName.equals(cmp.stdName));
		}
		return false;
	}
	
	public String toString(){
		return vertexName + "|" + stdName;
	}
}
