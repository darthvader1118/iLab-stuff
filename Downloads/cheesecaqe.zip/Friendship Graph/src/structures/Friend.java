package structures;

/**
 * 
 * @author Eric
 *	Vertex class for graph
 *fields: name of person, school attended, linked list of edges
 */
public class Friend {

	public String name;
	public String school;
	
	public NLL friends;
	
	public Friend(String name){
		this.name = name;
		friends = new NLL();
	}
	public Friend(String name, String school){
		this.name = name;
		this.school = school;
		friends = new NLL();
	}
	
	public boolean equals(Friend cmp){
		if(cmp != null){
			return (name == cmp.name && school == cmp.school);
		}
		return false;
	}
	
	public String toString(){
		if(school == null){
			return name + "|n";
		}else{
			return name + "|y|" + school;
		}
	}
}
