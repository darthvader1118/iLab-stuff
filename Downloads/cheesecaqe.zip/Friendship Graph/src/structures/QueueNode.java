package structures;

public class QueueNode{
	Friend data;
	QueueNode next;
	
	public QueueNode(Friend data, QueueNode next){
		this.data = data;
		this.next = next;
	}
}
