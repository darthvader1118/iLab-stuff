package structures;

import java.util.NoSuchElementException;

public class Queue {
		
	private QueueNode rear;
	private int size;
		
	public Queue() {
		rear = null;
		size = 0;
	}

	public void enqueue(Friend item) {
		QueueNode newItem = new QueueNode(item, null);
		if(rear == null){
			newItem.next = newItem;
		}else{
			newItem.next = rear.next;
			rear.next = newItem;
		}
		size++;
		rear = newItem;
	}
		
	public Friend dequeue() throws NoSuchElementException {
		if(rear == null){
			throw new NoSuchElementException("queue is empty");
		}
		Friend data = rear.next.data;
		if(rear == rear.next){
			rear = null;
		}else{
			rear.next = rear.next.next;
		}
		size--;
		return data;
		}
		
	public int size() {
		return size;
	}
		
	public boolean isEmpty() {
		return size == 0;
	}

}
