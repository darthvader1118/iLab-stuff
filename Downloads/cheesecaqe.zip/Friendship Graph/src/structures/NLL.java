package structures;

import java.util.NoSuchElementException;

/**
 * 
 * @author Eric
 *	Linked List class for edges
 *fields: tail and size, basically useless
 */
public class NLL{
   
	Neighbor tail;   
     
	int size;   
     
	public NLL(){
		tail = null;
        size = 0;
     }
     
	public void add(String vertexName, String stdName){
		Neighbor n = new Neighbor(vertexName,stdName);
		if(tail == null){
			tail = n;
			tail.next = tail;
		}else{
			n.next = tail.next;
			tail.next = n;
		}
		size++;
	}

	public void add(Neighbor n){
		if(tail == null){
			tail = n;
			tail.next = tail;
		}else{
			n.next = tail.next;
			tail.next = n;
		}
		size++;
	}
	
	public void delete(Neighbor toDelete) {
		
		if (tail == null){
			throw new NoSuchElementException();
		}
		
		if (tail == tail.next && tail.equals(toDelete)){
			tail = null;
			return;
		}
		
		Neighbor curr = tail.next;
		Neighbor prev = tail;
		
		do{
			if (curr.equals(toDelete)){
				if (curr == tail){
					tail = prev;
				}
				prev.next = curr.next;
				return;
			}
			
			prev = curr;
			curr = curr.next;
		}while(curr != tail.next);
		
		throw new NoSuchElementException();
	}

	public int indexOf(Neighbor n){
		if (size == 0){
			return -1;
		}
		Neighbor curr = tail.next;
		for (int i = 0; i < size; i++){
			if (n.equals(curr)){
				return i;
			}
			curr = curr.next;
		}
		return -1;
	}

	public int getSize(){
		return size;
	}
     
	public boolean isEmpty(){
		return (size == 0);
	}
	   
	public void clear(){
		tail = null;
		size = 0;
	}
	
	public boolean contains(Neighbor n){
		return indexOf(n) != -1;
	}
	
}