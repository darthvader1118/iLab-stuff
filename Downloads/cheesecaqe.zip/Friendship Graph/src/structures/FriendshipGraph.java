package structures;

import java.util.*;

/**
 * 
 * @author Eric
 *the actual freindship graph
 *fields: hashmap of vertexes, scanner for file
 */
public class FriendshipGraph {
	 
	public HashMap<String,Friend> adjlist;
	public ArrayList<String> indexes;
	public Scanner sc;
	public int numPeople;

	public FriendshipGraph() {
		adjlist = new HashMap<String,Friend>();
		indexes = new ArrayList<String>();
	}
	public FriendshipGraph(Scanner sc) {
		adjlist = new HashMap<String,Friend>();
		this.sc = sc;
		indexes = new ArrayList<String>();
	}
	
	//WORKS
	public void build(){
		if(sc.hasNextLine()){
			numPeople = Integer.parseInt(sc.nextLine()); //get the number of people
			for(int i = 0; i < numPeople; i++){
				String person = sc.nextLine(); //get the person's info
				String name,school;
				Friend newPerson;
				int indOne = person.indexOf('|');
				name = person.substring(0,indOne); //get the person's name
				if(person.charAt(indOne+1) == 'y'){ //if they have a school, get school name
					school = person.substring(indOne+3);
					newPerson = new Friend(name,school);
				}else{
					newPerson = new Friend(name);
				}
				adjlist.put(name,newPerson);
			}
			while(sc.hasNextLine()){ //begin populating the linked lists
				String connection = sc.nextLine();
				String nameOne,nameTwo;
				int indTwo = connection.indexOf('|');
				nameOne = connection.substring(0,indTwo); //get first person's name
				nameTwo = connection.substring(indTwo+1); //get second person's name
				Friend personOne = adjlist.get(nameOne);
				personOne.friends.add(personOne.name, nameTwo);
				Friend personTwo = adjlist.get(nameTwo);
				personTwo.friends.add(personTwo.name,nameOne);
			}
		}
		buildIndexes();
	}
	public void buildIndexes(){
		Iterator<String> it = adjlist.keySet().iterator();
		while(it.hasNext()){
			String s = it.next();
			indexes.add(s);
		}
	}
	
	//WORKS
	public FriendshipGraph studentsAtASchool(String schoolChecked){
		schoolChecked = schoolChecked.toLowerCase();
		FriendshipGraph ret = new FriendshipGraph();
		HashMap<String,Friend> map = adjlist;
		Iterator<String> it = map.keySet().iterator();
		while(it.hasNext()){ //find all students at a school, add to adjlist of a new graph
			String s = it.next();
			Friend buddy = map.get(s);
			if(buddy.school == null){
				continue;
			}
			if(buddy.school.equals(schoolChecked)){ //if at the right school
				Friend guy = new Friend(buddy.name, buddy.school); //create a new friend
				guy.friends = buddy.friends; //set it's LL equal
				guy.friends = editLL(guy, schoolChecked); //edit the LL
				ret.adjlist.put(guy.name,guy); //put it in the returned graph
				ret.numPeople++;
			}
		}
		return ret;
	}
	public NLL editLL(Friend buddy, String school){ //remove all neighbors from LL not from the right school
		Neighbor ptr = buddy.friends.tail;
		if(ptr == null){
			return null;
		}
		do{
			Friend dude = adjlist.get(ptr.stdName);
			String school2 = dude.school;
			if(school2 == null || !school2.equals(school)){
				Neighbor prev = ptr;
				ptr = ptr.next;
				buddy.friends.delete(prev);
			}else{
				ptr = ptr.next;
			}
		}while(ptr != buddy.friends.tail);
		return buddy.friends;
	}
	
	//WORKS
	public void print(){
		ArrayList<String> printed = new ArrayList<String>();
		System.out.println(numPeople); 
		Iterator<String> it = adjlist.keySet().iterator(); //iterate through the vertexes, print all of them out
		while(it.hasNext()){
			String s = it.next();
			Friend pal = adjlist.get(s);
			System.out.println(pal);
		}
		Iterator<String> it2 = adjlist.keySet().iterator(); //iterate through the vertexes, print all of the neighbors in their LL
		while(it2.hasNext()){ //this part does not work, prints a single extra neighbor
			String s = it2.next();
			Friend acquaintance = adjlist.get(s);
			Neighbor ptr = acquaintance.friends.tail;
			do{
				if(printed.indexOf(ptr.stdName) == -1){ //make sure the connection isn't already printed
					System.out.println(ptr);
				}
				ptr = ptr.next;
			}while(ptr != acquaintance.friends.tail);
			printed.add(s);
		}
	}
	
	//WORKS FUCKING YES
	public String introChain(String wantsIntro, String toIntro){
		String chain = "";
		if(!adjlist.containsKey(wantsIntro) || !adjlist.containsKey(toIntro)){
			return "These people do not exist ):";
		}else{
			ArrayList<Friend> path = getShortestPath(adjlist.get(wantsIntro), adjlist.get(toIntro));
			if(path != null){
				if(path.size() == 0){
					return "Unfortunately, there is no way for these people to meet";
				}else{
					for(int i = 0; i < path.size()-1; i++){
						chain += path.get(i).name + "--";
					}
					chain += toIntro;
				}
			}
		}
		return chain;
	}
	public ArrayList<Friend> getShortestPath(Friend src, Friend dst){
		Friend curr = null;
		ArrayList<Friend> shortestPath = new ArrayList<Friend>();
		
		Queue q = new Queue();
		q.enqueue(src);
		
		HashMap<Friend,Boolean> visited = new HashMap<Friend,Boolean>();
		visited.put(src,true);
		HashMap<Friend,Friend> previous = new HashMap<Friend,Friend>();
		
		while(!q.isEmpty()){
			curr = q.dequeue();
			if(curr.equals(dst)){
				break;
			}else{
				Neighbor ptr = curr.friends.tail;
				do{
					if(!visited.containsKey(adjlist.get(ptr.stdName))){
						q.enqueue(adjlist.get(ptr.stdName));
						visited.put(adjlist.get(ptr.stdName),true);
						previous.put(adjlist.get(ptr.stdName), curr);
					}
					ptr = ptr.next;
				}while(ptr != curr.friends.tail);
			}
		}
		if(!curr.equals(dst)){
			return null;
		}else{
			for(Friend f = dst; f != null; f = previous.get(f)){
				shortestPath.add(f);
			}
			Collections.reverse(shortestPath);
			return shortestPath;
		}
	}
	
	public ArrayList<FriendshipGraph> cliques(){
		return null;
	}
	
	public String connectors(){
		return "";
	}
}
